<?php

namespace Drupal\smtp\Exception;

/**
 * General exception for errors thrown by PHPMailer.
 */
class PHPMailerException extends \Exception {

}
